package com.toppr.eve.ui;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.android.volley.toolbox.NetworkImageView;
import com.toppr.eve.R;
import com.toppr.eve.app.EveApp;
import com.toppr.eve.domain.Event;
import com.toppr.eve.util.Serializable;

/**
 * Created by Satvik on 24/09/16.
 */

public class EventDetailsFragment extends Fragment {

    public static final String EVENT_DATA_KEY = "event";

    private Event mEvent;

    public EventDetailsFragment() {
        // NOP
    }

    public static EventDetailsFragment getInstance(String eventData) {
        EventDetailsFragment detailsFragment = new EventDetailsFragment();
        Bundle args = new Bundle();
        args.putString(EVENT_DATA_KEY, eventData);
        detailsFragment.setArguments(args);
        return detailsFragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_event_details, container, false);

        Bundle arguments = getArguments();
        mEvent = (Event) Serializable.fromJson(arguments.getString(EVENT_DATA_KEY), Event.class);

        TextView eventExperience = (TextView) rootView.findViewById(R.id.experience);
        eventExperience.setText(mEvent.getExperience());

        if (mEvent.getExperience() != null && mEvent.getExperience().length() > 1) {
            eventExperience.setText(mEvent.getExperience());
            eventExperience.setVisibility(View.VISIBLE);
        } else {
            eventExperience.setVisibility(View.GONE);
        }

        TextView eventDescription = (TextView) rootView.findViewById(R.id.description);
        eventDescription.setText(mEvent.getDescription());
        TextView eventName = (TextView) rootView.findViewById(R.id.name);
        eventName.setText(mEvent.getName());

        NetworkImageView eventIcon = (NetworkImageView) rootView.findViewById(R.id.event_icon);
        eventIcon.setImageUrl(mEvent.getImage(), ((EveApp)getActivity().getApplicationContext()).getImageLoader());

        return rootView;
    }
}
