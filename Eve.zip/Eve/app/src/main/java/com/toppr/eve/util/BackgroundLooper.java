package com.toppr.eve.util;

import android.os.HandlerThread;
import android.os.Looper;
import android.os.Process;

/**
 * Created by Satvik on 24/09/16.
 */
public class BackgroundLooper {
    private static Looper sLooper;

    public synchronized static Looper getInstance() {
        if (sLooper == null) {
            HandlerThread thread = new HandlerThread(BackgroundLooper.class.getName(),
                    Process.THREAD_PRIORITY_BACKGROUND);
            thread.start();
            sLooper = thread.getLooper();
        }
        return sLooper;
    }
}
