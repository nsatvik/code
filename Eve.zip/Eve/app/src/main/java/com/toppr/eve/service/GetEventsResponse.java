package com.toppr.eve.service;

import com.toppr.eve.domain.Event;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Satvik on 24/09/16.
 */

public class GetEventsResponse {

    private List<Event> websites;
    private Integer quoteMax;
    private Integer quoteAvailable;

    public Integer getQuoteAvailable() {
        return quoteAvailable;
    }

    public void setQuoteAvailable(Integer quoteAvailable) {
        this.quoteAvailable = quoteAvailable;
    }

    public Integer getQuoteMax() {
        return quoteMax;
    }

    public void setQuoteMax(Integer quoteMax) {
        this.quoteMax = quoteMax;
    }

    public List<Event> getWebsites() {
        return websites;
    }

    public void setWebsites(List<Event> websites) {
        this.websites = websites;
    }
}
