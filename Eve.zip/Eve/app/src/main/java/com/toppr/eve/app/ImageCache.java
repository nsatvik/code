package com.toppr.eve.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.LruCache;

import com.android.volley.toolbox.ImageLoader;

/**
 * Created by Satvik on 24/09/16.
 */

public class ImageCache implements ImageLoader.ImageCache {

    private static ImageCache sImageCache = new ImageCache();

    private final LruCache<String, Bitmap> cache = new LruCache<>(20);


    public static ImageCache getInstance() {
        return sImageCache;
    }


    @Override
    public Bitmap getBitmap(String url) {
        return cache.get(url);
    }

    @Override
    public void putBitmap(final String url, final Bitmap bitmap) {
        cache.put(url, bitmap);
    }
}
