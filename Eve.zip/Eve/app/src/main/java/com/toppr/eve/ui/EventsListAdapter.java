package com.toppr.eve.ui;

import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.media.Image;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;
import com.toppr.eve.R;
import com.toppr.eve.app.EveApp;
import com.toppr.eve.domain.Event;
import com.toppr.eve.util.Serializable;

import java.util.List;

/**
 * Created by Satvik on 24/09/16.
 */

public class EventsListAdapter extends RecyclerView.Adapter<EventsListAdapter.ViewHolder> {

    private List<Event> mEvents;
    private Fragment mContainerFragment;
    private Context mContext;
    private ImageLoader mImageLoader;

    public EventsListAdapter(Fragment fragment) {
        this.mContainerFragment = fragment;
        this.mContext = fragment.getActivity();
        mImageLoader = ((EveApp) mContext.getApplicationContext()).getImageLoader();
    }

    public void setEvents(List<Event> events) {
        this.mEvents = events;
        notifyDataSetChanged();
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        View v = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.event_list_item, viewGroup, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final Event event = mEvents.get(position);

        holder.eventImage.setImageUrl(event.getImage(), mImageLoader);

        holder.nameTextview.setText(event.getName());
        if (event.getExperience() != null && event.getExperience().length() > 1) {
            holder.experienceTextview.setText(event.getExperience());
            holder.experienceTextview.setVisibility(View.VISIBLE);
        } else {
            holder.experienceTextview.setVisibility(View.GONE);
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent showDetailsIntent = new Intent(mContext, DetailsActivity.class);
                showDetailsIntent.putExtra(EventDetailsFragment.EVENT_DATA_KEY, Serializable.toJson(event));
                mContainerFragment.startActivity(showDetailsIntent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mEvents != null ? mEvents.size() : 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView nameTextview;
        TextView experienceTextview;
        NetworkImageView eventImage;
        View itemView;

        public ViewHolder(View itemView) {
            super(itemView);
            this.itemView = itemView;
            nameTextview = (TextView) itemView.findViewById(R.id.name);
            experienceTextview = (TextView) itemView.findViewById(R.id.experience);
            eventImage = (NetworkImageView) itemView.findViewById(R.id.event_icon);
        }
    }
}
