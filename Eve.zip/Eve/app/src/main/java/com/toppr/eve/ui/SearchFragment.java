package com.toppr.eve.ui;

import android.app.Fragment;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.toppr.eve.R;
import com.toppr.eve.app.EveApp;
import com.toppr.eve.domain.Event;
import com.toppr.eve.service.EventsApi;
import com.toppr.eve.service.GetEventsResponse;

import java.util.ArrayList;
import java.util.List;

import static android.view.View.GONE;

public class SearchFragment extends Fragment implements TextWatcher {
    private static final String LOGTAG = SearchFragment.class.getSimpleName();

    private EventsListAdapter mEventsListAdapter;
    private EventsApi mEventsApi;
    private TextView mHintText;
    private List<Event> mEvents = new ArrayList<>();
    private ProgressBar mProgBar;
    private Response.Listener<GetEventsResponse> mResponseListener = new Response.Listener<GetEventsResponse>() {
        @Override
        public void onResponse(GetEventsResponse response) {
            Log.v(LOGTAG, "Got events response!");
            mEvents.clear();
            mProgBar.setVisibility(GONE);
            if (response.getWebsites() != null) {
                mEvents.addAll(response.getWebsites());
                mEventsListAdapter.setEvents(mEvents);
                Log.v(LOGTAG, "size - " + mEvents.size());
            }

            if (mEvents.isEmpty()) {
                mHintText.setText(R.string.no_events);
                mHintText.setVisibility(View.VISIBLE);
            } else {
                mHintText.setVisibility(View.GONE);
            }
        }
    };

    private Response.ErrorListener mErrorListener = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            Log.v(LOGTAG, "error - " + error.networkResponse);
            mProgBar.setVisibility(GONE);
            mHintText.setText(R.string.error_message);
            mHintText.setVisibility(View.VISIBLE);
        }
    };


    public SearchFragment() {
    }

    public static SearchFragment getInstance() {
        return new SearchFragment();
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView =  inflater.inflate(R.layout.fragment_search, container, false);
        RecyclerView eventsListView = (RecyclerView) rootView.findViewById(R.id.search_list);
        eventsListView.setLayoutManager(new LinearLayoutManager(getActivity()));
        eventsListView.setItemAnimator(new DefaultItemAnimator());
        mEventsListAdapter = new EventsListAdapter(this);
        eventsListView.setAdapter(mEventsListAdapter);

        mHintText = (TextView) rootView.findViewById(R.id.hint_text);

        EditText searchEditText = (EditText) rootView.findViewById(R.id.search_edit_text);
        searchEditText.addTextChangedListener(this);

        mProgBar = (ProgressBar) rootView.findViewById(R.id.prog_bar);
        mProgBar.setVisibility(View.VISIBLE);

        EveApp app = (EveApp) getActivity().getApplicationContext();
        mEventsApi = new EventsApi(getString(R.string.events_base_url), app.getRequestQueue());
        mEventsApi.getEvents(mResponseListener, mErrorListener);

        return rootView;
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }

    @Override
    public void afterTextChanged(Editable queryText) {
        String filterText = queryText.toString().toLowerCase();
        List<Event> events = new ArrayList<>(mEvents.size());
        for (Event event : mEvents) {
            if (event.getName().toLowerCase().contains(filterText)
                    || event.getCategory().toLowerCase().contains(filterText)) {
                events.add(event);
            }
        }
        mEventsListAdapter.setEvents(events);
    }
}
