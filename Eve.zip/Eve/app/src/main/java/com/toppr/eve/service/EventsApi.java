package com.toppr.eve.service;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Satvik on 24/09/16.
 */

public class EventsApi {

    private String baseUrl;
    private RequestQueue requestQueue;

    public EventsApi(String baseUrl, RequestQueue requestQueue) {
        this.baseUrl = baseUrl;
        this.requestQueue = requestQueue;
    }

    public void getEvents(Response.Listener<GetEventsResponse> responseListener, Response.ErrorListener errorListener) {
        Map<String, String> headers = new HashMap<>();
        headers.put("content-type", "application/json");
        JsonRequest<GetEventsResponse> eventsRequest = new JsonRequest<>(Request.Method.GET,
                baseUrl + "/api/toppr_events?type=json&query=list_events", GetEventsResponse.class,
                headers, responseListener, errorListener);
        requestQueue.add(eventsRequest);
    }
}
