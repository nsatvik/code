package com.toppr.eve.util;

import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.lang.reflect.Modifier;
import java.lang.reflect.Type;

/**
 * Created by Satvik on 24/09/16.
 */

public class Serializable {
    public static final Gson JSON_SERIALIZER;

    static {
        JSON_SERIALIZER = new GsonBuilder()
                .setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES)
                .create();
    }

    public static String toJson(Object object) {
        return JSON_SERIALIZER.toJson(object);
    }

    public static Object fromJson(String json, Type type) {
        return JSON_SERIALIZER.fromJson(json, type);
    }

    public static Object fromJson(String json, Class t) {
        return JSON_SERIALIZER.fromJson(json, t);
    }
}
